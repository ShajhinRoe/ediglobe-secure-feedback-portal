const express = require("express");
const session = require("express-session");
const sqlite3 = require("sqlite3").verbose();
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const path = require("path");
const { body, validationResult } = require("express-validator");

const app = express();
const db = new sqlite3.Database("./db.sqlite");

db.serialize(() => {
  db.run(`CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL
  )`);

  db.run(`CREATE TABLE IF NOT EXISTS feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    message TEXT NOT NULL,
    FOREIGN KEY(user_id) REFERENCES users(id)
  )`);
});

app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));
app.use(helmet());
app.use(express.urlencoded({ extended: false }));
app.use(
  session({
    secret: "ediglobe_secure",
    resave: false,
    saveUninitialized: false
  })
);

function requireLogin(req, res, next) {
  if (!req.session.user) return res.redirect("/login");
  next();
}

app.get("/", (req, res) => res.redirect("/login"));

app.get("/register", (req, res) => res.render("register", { errors: [] }));
app.post("/register", [
  body("username").notEmpty(),
  body("email").isEmail(),
  body("password").isLength({ min: 6 })
], (req, res) => {
  const { username, email, password } = req.body;
  const errors = validationResult(req);
  if (!errors.isEmpty()) return res.render("register", { errors: errors.array() });

  const hash = bcrypt.hashSync(password, 10);
  db.run(`INSERT INTO users(username,email,password_hash)VALUES(?,?,?)`,
  [username,email,hash], err=>{
    if(err) return res.render("register",{errors:[{msg:"User Exists"}]});
    res.redirect("/login");
  });
});

app.get("/login", (req,res)=>res.render("login",{ errors: [] }));
app.post("/login", (req,res)=>{
  const { username,password } = req.body;
  db.get(`SELECT * FROM users WHERE username=?`,[username],(err,user)=>{
    if(!user || !bcrypt.compareSync(password,user.password_hash))
      return res.render("login",{errors:[{msg:"Invalid"}]});
    req.session.user=user;
    res.redirect("/dashboard");
  });
});

app.get("/dashboard", requireLogin,(req,res)=>{
  db.all(`SELECT message FROM feedback WHERE user_id=?`,
  [req.session.user.id], (err,feedbacks)=>res.render("dashboard",{feedbacks}));
});

app.post("/feedback", requireLogin,(req,res)=>{
  db.run(`INSERT INTO feedback(user_id,message)VALUES(?,?)`,
  [req.session.user.id, req.body.message],()=>res.redirect("/dashboard"));
});

app.post("/logout", requireLogin,(req,res)=>req.session.destroy(()=>res.redirect("/login")));

app.listen(3000,()=>console.log("Running http://localhost:3000"));
